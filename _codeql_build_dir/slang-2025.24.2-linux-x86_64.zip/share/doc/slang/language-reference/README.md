> Note: This document is a work in progress. It is both incomplete and, in many cases, inaccurate.

Slang Language Reference
========================

Contents
--------

* [1 - Introduction](01-introduction.md)
* [2 - Lexical Structure](02-lexical-structure.md)
* [3 - Preprocessor](03-preprocessor.md)
* [4 - Types](04-types.md)
* [5 - Expressions](05-expressions.md)
* [6 - Statements](06-statements.md)
* [7 - Declarations](07-declarations.md)
* [8 - Attributes](08-attributes.md)
